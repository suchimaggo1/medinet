﻿ using Medinet.API.Contracts;
using Medinet.API.Domain;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Medinet.API_xUnit
{
    public class PhotoServiceFake : IPhotoService
    {
        private readonly List<Photo> _photoDB;
        public PhotoServiceFake()
        {
            _photoDB = new List<Photo>()
            {
                new Photo(){Id=100,Name="John",Description="Developer"},
                new Photo(){Id=101,Name="Jim",Description="Sr. Developer"},
                new Photo(){Id=102,Name="Jack",Description="Tech Lead"},
                new Photo(){Id=103,Name="Jim",Description="Sr. Developer"},
                new Photo(){Id=104,Name="Jack",Description="Tech Lead"}
            };
        }
        public IEnumerable<Photo> GetAllPhotos()
        {
            return _photoDB;
        }

        public Photo Add(Photo newItem)
        {
            Random rnd = new Random();
            newItem.Id = rnd.Next(1, 1000);
            _photoDB.Add(newItem);
            return newItem;
        }


        public Photo GetById(int id)
        {
            return _photoDB.Where(a => a.Id == id)
                 .FirstOrDefault();
        }

        public void Remove(int id)
        {
            var existing = _photoDB.First(a => a.Id == id);
            _photoDB.Remove(existing);
        }

        public Photo Update(Photo photo)
        {
             

            return photo;
        }


         
    }
}

﻿using Medinet.API.Domain;
using Medinet.API.Repositories;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Medinet.API.EFRepositories
{
    public class PhotoRepository : IPhotoRepository
    {
        PhotoContext _context;
        public PhotoRepository(PhotoContext context)
        {
            _context = context;

        }
        public async Task<Photo> Add(Photo item)
        {
            _context.Photo.Add(item);
           await  _context.SaveChangesAsync();
            return item;
        }

        public async Task<IEnumerable<Photo>> GetAllPhotos()
        {
            return await _context.Photo.ToListAsync();
        }

        public async Task<Photo> GetById(int id)
        {
            var photo = await _context.Photo.FirstAsync(item => item.Id == id);
            if (photo == null)
            {
                throw new ApplicationException("Not Found");
            }
            return photo;
        }

        public async Task Remove(int id)
        {
            var photo = await _context.Photo.FindAsync(id);
            if (photo == null)
            {
                throw new ApplicationException("Not Found");
            }
            _context.Photo.Remove(photo);
            await _context.SaveChangesAsync();
        }

        public async Task Update(Photo item)
        {
            _context.Entry(item).State = EntityState.Modified;
            await _context.SaveChangesAsync();
        }
    }
}

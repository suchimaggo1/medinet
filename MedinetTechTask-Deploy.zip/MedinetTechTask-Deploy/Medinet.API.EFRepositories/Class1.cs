﻿using System;

namespace CRUD.API.EFRepositories
{
    public class Class1
    {
    }
}

﻿using Medinet.API.Domain;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Medinet.BusinessObjects
{
   public interface IPhotoBO
    {
        Task<IEnumerable<Photo>> GetAllPhotos();
        Task<Photo> GetById(int id);
        Photo Add(Photo item);
        Task Update(Photo item);
        Task Remove(int id);
    }
}

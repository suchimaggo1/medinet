﻿using Medinet.API.Domain;
using Medinet.API.Repositories;
using Medinet.BusinessObjects;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CRUD.BusinessObjects
{
    public class PhotoBO : IPhotoBO
    {
        IPhotoRepository _repository;
        public PhotoBO(IPhotoRepository repository)
        {
            _repository = repository;
        }
         
        public    Photo Add(Photo emp)
        {
              _repository.Add(emp);
            return emp;
        }

        public async Task<IEnumerable<Photo>> GetAllPhotos()
        {
            return await _repository.GetAllPhotos();
        }

        public async Task<Photo> GetById(int id)
        {
            return await _repository.GetById(id);
        }

        public async Task Remove(int id)
        {
            await _repository.Remove(id);
        }

        public async Task Update(Photo emp)
        {
            await _repository.Update(emp);
        }
    }
}

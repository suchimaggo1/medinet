﻿using Medinet.API.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Medinet.API.Data
{
    public class PhotoDataSeed
    {
        public static async Task SeedAsync(PhotoContext context)
        {
            if (!context.Photo.Any())
            {
                context.Photo.AddRange(GetPreconfiguredPhotoItems());
                await context.SaveChangesAsync();
            }
        }

        static IEnumerable<Photo> GetPreconfiguredPhotoItems()
        {
            return new List<Photo>()
             {
             new Photo() {Name="Tim",Description="CIO"},
             new Photo() {Name="Shyam", Description="Technical Go - to "}

             };
        }
    }
}

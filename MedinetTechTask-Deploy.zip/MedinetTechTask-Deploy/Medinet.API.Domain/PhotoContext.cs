﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Medinet.API.Domain;

namespace Medinet.API.Domain
{
    public class PhotoContext : DbContext
    {
        public PhotoContext (DbContextOptions<PhotoContext> options)
            : base(options)
        {
        }

        public DbSet<Medinet.API.Domain.Photo> Photo { get; set; }
    }
}

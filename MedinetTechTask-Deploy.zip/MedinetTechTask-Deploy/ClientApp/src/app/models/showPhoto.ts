export class ShowPhoto {
  id?: number;
  name: string;
  description: string;

  }

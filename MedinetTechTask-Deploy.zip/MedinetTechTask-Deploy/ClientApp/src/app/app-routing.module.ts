import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ShowPhotosComponent } from './show-photos/show-photos.component';
import { ShowPhotoComponent } from './show-photo/show-photo.component';
import { ShowPhotoAddEditComponent } from './show-photo-add-edit/show-photo-add-edit.component';

const routes: Routes = [
  { path: '', component: ShowPhotosComponent, pathMatch: 'full' },
  { path: 'showphoto/:id', component: ShowPhotoComponent },
  { path: 'add', component: ShowPhotoAddEditComponent },
  { path: 'showphoto/edit/:id', component: ShowPhotoAddEditComponent },
  { path: '**', redirectTo: '/' }



];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { ShowPhotoService } from '../services/show-photo.service';
import { ShowPhoto } from '../models/showPhoto';

@Component({
  selector: 'app-show-photo-add-edit',
  templateUrl: './show-photo-add-edit.component.html',
  styleUrls: ['./show-photo-add-edit.component.scss']
})
export class ShowPhotoAddEditComponent implements OnInit {
  form: FormGroup;
  actionType: string;
  formName: string;
  formDescription: string;
  Id: number;
  errorMessage: any;
  existingShowPhoto: ShowPhoto;
  
  constructor(private showPhotoService: ShowPhotoService, 
              private formBuilder: FormBuilder, private avRoute: ActivatedRoute, private router: Router)
   {
    const idG = 'id';
    this.actionType = 'Add';
    this.formName = 'name';
    this.formDescription = 'description';
    if (this.avRoute.snapshot.params[idG]) {
      this.Id = this.avRoute.snapshot.params[idG];
    }

    this.form = this.formBuilder.group(
      {
        term: ['', [Validators.required]],
        definition: ['', [Validators.required]],
      }
    );
  }

  ngOnInit() {

    if (this.Id > 0) {
      this.actionType = 'Edit';
      this.showPhotoService.getShowPhoto(this.Id)
        .subscribe(data => (
          this.existingShowPhoto = data,
          this.form.controls[this.formName].setValue(data.name),
          this.form.controls[this.formDescription].setValue(data.description)
        ));
    }
  }

  save() {
    if (!this.form.valid) {
      const ans = alert('form is blank. please fill data.');
      return;
    }

    if (this.actionType === 'Add') {
      let showPhoto: ShowPhoto = {
        name: this.form.get(this.formName).value,
        description: this.form.get(this.formDescription).value
      };
      this.showPhotoService.saveShowPhoto(showPhoto)
        .subscribe((data) => {
          this.router.navigate(['/showPhoto', data.id]);
        });
    }

    if (this.actionType === 'Edit') {
      let showPhoto: ShowPhoto = {
        id: this.existingShowPhoto.id,
        name: this.form.get(this.formName).value,
        description: this.form.get(this.formDescription).value
      };
      this.showPhotoService.updateShowPhoto(showPhoto.id, showPhoto)
        .subscribe((data) => {
          this.router.navigate(['/showPhoto']);
        });
    }
  }

  cancel() {
    this.router.navigate(['/']);
  }

  get title() { return this.form.get(this.title); }
  get body() { return this.form.get(this.formDescription); }
}

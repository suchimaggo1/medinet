import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowPhotoAddEditComponent } from './show-photo-add-edit.component';

describe('ShowPhotoAddEditComponent', () => {
  let component: ShowPhotoAddEditComponent;
  let fixture: ComponentFixture<ShowPhotoAddEditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ShowPhotoAddEditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShowPhotoAddEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

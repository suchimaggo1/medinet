import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
import { ShowPhoto } from '../models/showPhoto';

@Injectable({
  providedIn: 'root'
})
export class ShowPhotoService {
  myAppUrl: string;
  myApiUrl: string;
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json; charset=utf-8'
    })
  };
  constructor(private http: HttpClient) {
    this.myAppUrl = environment.appUrl;
    this.myApiUrl = 'api/Photos/';
    }

    getShowPhotos(): Observable<ShowPhoto[]> {
       return this.http.get<ShowPhoto[]>(this.myAppUrl + this.myApiUrl)
      .pipe(
        retry(1),
        catchError(this.errorHandler)
      );
  }

  getShowPhoto(postId: number): Observable<ShowPhoto> {
      return this.http.get<ShowPhoto>(this.myAppUrl + this.myApiUrl + postId)
      .pipe(
        retry(1),
        catchError(this.errorHandler)
      );
  }

  saveShowPhoto(showPhoto): Observable<ShowPhoto> {
    return this.http.post<ShowPhoto>(this.myAppUrl + this.myApiUrl, JSON.stringify(showPhoto), this.httpOptions)
    .pipe(
      retry(1),
      catchError(this.errorHandler)
    );
}
updateShowPhoto(postId: number, showPhoto): Observable<ShowPhoto> {
  return this.http.put<ShowPhoto>(this.myAppUrl + this.myApiUrl + postId, JSON.stringify(showPhoto), this.httpOptions)
  .pipe(
    retry(1),
    catchError(this.errorHandler)
  );
}
 
deleteShowPhoto(postId: number): Observable<ShowPhoto> {
  return this.http.delete<ShowPhoto>(this.myAppUrl + this.myApiUrl + postId)
  .pipe(
    retry(1),
    catchError(this.errorHandler)
  );
}

errorHandler(error) {
let errorMessage = '';
if (error.error instanceof ErrorEvent) {
  // Get client-side error
  errorMessage = error.error.message;
} else {
  // Get server-side error
  errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
}
console.log(errorMessage);
return throwError(errorMessage);
}

}

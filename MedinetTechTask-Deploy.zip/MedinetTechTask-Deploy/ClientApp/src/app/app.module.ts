import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ShowPhotosComponent } from './show-photos/show-photos.component';
import { ShowPhotoComponent } from './show-photo/show-photo.component';
import { ShowPhotoAddEditComponent } from './show-photo-add-edit/show-photo-add-edit.component';
import { ShowPhotoService } from './services/show-photo.service';

@NgModule({
  declarations: [
    AppComponent,
    ShowPhotosComponent,
    ShowPhotoComponent,
    ShowPhotoAddEditComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    ReactiveFormsModule
  ],
  providers: [
    ShowPhotoService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }

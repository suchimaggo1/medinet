import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { ShowPhotoService } from '../services/show-photo.service';
import { ShowPhoto } from '../models/showPhoto';

@Component({
  selector: 'app-show-photos',
  templateUrl: './show-photos.component.html',
  styleUrls: ['./show-photos.component.scss']
})
export class ShowPhotosComponent implements OnInit {
  showPhotos$: Observable<ShowPhoto[]>;

  constructor(private showPhotoService: ShowPhotoService) {
  }


  ngOnInit(): void {
    this.loadShowPhotos();
  }

  loadShowPhotos() {
    this.showPhotos$ = this.showPhotoService.getShowPhotos();
    
  }

  delete(Id) {
    const ans = confirm('Do you want to delete photo post with id: ' + Id);
    if (ans) {
      this.showPhotoService.deleteShowPhoto(Id).subscribe((data) => {
        this.loadShowPhotos();
      });
    }
  }
  OpenCamera()
    {
      window.open('http://localhost:50861/');
      //   alert('new window');
    }
}

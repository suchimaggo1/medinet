﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Medinet.API.Data;
using Medinet.API.Contracts;
using CRUD.BusinessObjects;
using Medinet.API.Domain;
using Medinet.BusinessObjects;

namespace Medinet.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PhotosController : ControllerBase
    {
       
        private readonly IPhotoService _service;
        public PhotosController(IPhotoService service)
        {
            _service = service;
        }
        // GET: api/GetPhotos
        [HttpGet]
        public ActionResult<IEnumerable<Photo>> GetPhotos()
        {
            var items = _service.GetAllPhotos();
            return Ok(items);
        }

        // GET:  
        [HttpGet("{id}")]
        public ActionResult<Photo> GetPhoto(int id)
        {
            var photo = _service.GetById(id);

            if (photo == null)
            {
                return NotFound();
            }

            return Ok(photo);
        }
        // POST: api/PostPhoto
        [HttpPost]
        [ProducesResponseType(StatusCodes.Status201Created)]

        public ActionResult PostPhoto([FromBody] Photo photo)
        {

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            photo = _service.Add(photo);

            return CreatedAtAction("GetPhoto", new { id = photo.Id }, photo);
        }

        // DELETE: api/Photo/5
        [HttpDelete("{id}")]
        public ActionResult DeletePhoto(int id)
        {

            var photo = _service.GetById(id);

            if (photo == null)
            {
                return NotFound();
            }
            _service.Remove(id);

            return Ok(photo);

           
        }
        // PUT: api/Photos/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPut("{id}")]
        public IActionResult PutPhoto(int id, Photo photo)
        {
            if (id != photo.Id)
            {
                return BadRequest();
            }
            try
            {
                _service.Update(photo);

            }
            catch (ApplicationException ex)
            {
                if (ex.Message == "Not Found")
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();

        }
        
    }
}

﻿using Medinet.API.Contracts;
using Medinet.API.Domain;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Threading.Tasks;

namespace Medinet.API.Services
{
    public class PhotoService : IPhotoService
    {
        private readonly PhotoContext _context;

        public PhotoService(PhotoContext context)
        {
            _context = context;
        }
        public Photo Add(Photo photo)
        {
            _context.Photo.Add(photo);
            _context.SaveChangesAsync();
            return photo;
        }

        public IEnumerable<Photo> GetAllPhotos()
        {
            return _context.Photo.ToList();
        }
        public  void Remove(int id)
        {
            var existingEmp=_context.Photo.Find(id);
            if(existingEmp==null)
            {
                return;
            }
           Photo emp= _context.Photo.Find(id);
            _context.Remove(emp);
            _context.SaveChanges();

        }
        public Photo GetById(int id)
        {
            return _context.Photo.Find(id);
        }

        public Photo Update(Photo emp)
        {
            _context.Entry<Photo>(emp).State = EntityState.Modified;
            _context.SaveChanges();
            return emp;
        }
    }
}

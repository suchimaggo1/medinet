﻿using Medinet.API.Domain;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Medinet.API.Contracts
{
   public interface IPhotoService
    {
        IEnumerable<Photo> GetAllPhotos();
        Photo Add(Photo photo);
        Photo GetById(int id);
        void Remove(int id);
        Photo Update(Photo photo);
    }
}

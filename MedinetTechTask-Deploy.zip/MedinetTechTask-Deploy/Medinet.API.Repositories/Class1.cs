﻿using System;

namespace CRUD.API.Repositories
{
    public class Class1
    {
    }
}

﻿using Medinet.API.Domain;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Medinet.API.Repositories
{
  public  interface IPhotoRepository
    {
        Task<IEnumerable<Photo>> GetAllPhotos();
        Task<Photo> GetById(int id);
        Task<Photo> Add(Photo item);
        Task Update(Photo item);
        Task Remove(int id);
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Medinet.Models
{
    public class CameraModel
    {
        public string webcam { get; set; }
    }
}
